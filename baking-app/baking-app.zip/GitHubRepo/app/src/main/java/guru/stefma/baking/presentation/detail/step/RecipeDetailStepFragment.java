package guru.stefma.baking.presentation.detail.step;

import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import guru.stefma.baking.R;
import guru.stefma.baking.presentation.model.StepViewModel;
import guru.stefma.baking.presentation.video.VideoPlayerHelper;
import net.grandcentrix.thirtyinch.TiFragment;

public class RecipeDetailStepFragment extends TiFragment<RecipeDetailStepPresenter, RecipeDetailStepView>
        implements RecipeDetailStepView {

    private static final String BUNDLE_KEY_STEP = "bundle_key_step";

    private SimpleExoPlayer mPlayer;

    @Nullable
    private StepViewModel mStep;

    public static RecipeDetailStepFragment newInstance() {
        return new RecipeDetailStepFragment();
    }

    @NonNull
    @Override
    public RecipeDetailStepPresenter providePresenter() {
        return new RecipeDetailStepPresenter();
    }

    @Nullable
    @Override
    public View onCreateView(
            final LayoutInflater inflater,
            @Nullable final ViewGroup container,
            @Nullable final Bundle savedInstanceState
    ) {
        super.onCreateView(inflater, container, savedInstanceState);
        final View view = inflater.inflate(R.layout.fragment_recipe_step, container, false);
        if (savedInstanceState != null && savedInstanceState.containsKey(BUNDLE_KEY_STEP)) {
            mStep = savedInstanceState.getParcelable(BUNDLE_KEY_STEP);
            updateUiWithStep(view, mStep);
        }
        return view;
    }

    public void setStep(@NonNull final StepViewModel step) {
        mStep = step;
        updateUiWithStep(getView(), step);
    }

    private void updateUiWithStep(@NonNull final View view, @NonNull final StepViewModel step) {
        final TextView stepTitle = view.findViewById(R.id.fragment_recipe_step_title);
        stepTitle.setText(step.getStep());

        final TextView stepDesc = view.findViewById(R.id.fragment_recipe_step_description);
        stepDesc.setText(step.getDescription());

        final PlayerView playerView = view.findViewById(R.id.fragment_recipe_step_video);
        if (TextUtils.isEmpty(step.getVideoUrl())) {
            playerView.setVisibility(View.GONE);
            return;
        } else {
            playerView.setVisibility(View.VISIBLE);
        }

        // https://codelabs.developers.google.com/codelabs/exoplayer-intro/
        mPlayer = VideoPlayerHelper.createExoPlayerInstance(requireContext());
        playerView.setPlayer(mPlayer);

        final MediaSource source = VideoPlayerHelper.createHttpMediaSource(Uri.parse(step.getVideoUrl()));
        mPlayer.prepare(source, true, false);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    @Override
    public void onSaveInstanceState(final Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(BUNDLE_KEY_STEP, mStep);
    }
}
