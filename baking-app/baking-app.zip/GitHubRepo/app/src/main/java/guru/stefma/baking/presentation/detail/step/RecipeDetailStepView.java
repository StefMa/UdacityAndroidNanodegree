package guru.stefma.baking.presentation.detail.step;

import net.grandcentrix.thirtyinch.TiView;

interface RecipeDetailStepView extends TiView {

}
