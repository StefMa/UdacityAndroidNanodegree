package guru.stefma.baking.presentation.detail;

import net.grandcentrix.thirtyinch.TiView;

interface RecipeDetailView extends TiView {

}
