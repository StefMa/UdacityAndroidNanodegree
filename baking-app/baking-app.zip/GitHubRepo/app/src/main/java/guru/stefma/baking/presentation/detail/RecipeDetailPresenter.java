package guru.stefma.baking.presentation.detail;

import net.grandcentrix.thirtyinch.TiPresenter;

class RecipeDetailPresenter extends TiPresenter<RecipeDetailView>{

}
