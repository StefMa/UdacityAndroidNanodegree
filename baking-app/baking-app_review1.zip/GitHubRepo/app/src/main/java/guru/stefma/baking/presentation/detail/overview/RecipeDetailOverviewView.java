package guru.stefma.baking.presentation.detail.overview;

import net.grandcentrix.thirtyinch.TiView;

interface RecipeDetailOverviewView extends TiView {

}
