package guru.stefma.baking.presentation.detail.step;

import net.grandcentrix.thirtyinch.TiPresenter;

class RecipeDetailStepPresenter extends TiPresenter<RecipeDetailStepView>{

}
