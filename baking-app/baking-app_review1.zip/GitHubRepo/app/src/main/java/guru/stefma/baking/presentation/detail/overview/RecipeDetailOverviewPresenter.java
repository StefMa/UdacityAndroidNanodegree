package guru.stefma.baking.presentation.detail.overview;

import net.grandcentrix.thirtyinch.TiPresenter;

class RecipeDetailOverviewPresenter extends TiPresenter<RecipeDetailOverviewView>{

}
