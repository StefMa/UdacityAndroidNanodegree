package guru.stefma.popularmovies.data.local.entity;

public class LocalMovieFavoriteEntity {

    public int mId;

    public String mTitle;

}
