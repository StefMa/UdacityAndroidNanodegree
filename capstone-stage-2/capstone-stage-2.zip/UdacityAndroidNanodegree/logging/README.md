# Choicm Logging
Use this module in modules for logging in different modules the same way.

## Configuration
Currently it will only log if we are on a **debug** build.
It will **not** log if you build the App from an other **buildType**.

## Timber
This will expose **Timber** to the modules which you can use for logging. 